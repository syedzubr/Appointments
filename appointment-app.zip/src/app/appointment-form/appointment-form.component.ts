import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { AppointmentForm } from '../appointment-form';

@Component({
  selector: 'app-appointment-form',
  templateUrl: './appointment-form.component.html',
  styleUrls: ['./appointment-form.component.css'],
})
export class AppointmentFormComponent implements OnInit {
  constructor(private appService: AppService) {}

  powers = ['Really Smart', 'Super Flexible', 'Super Hot', 'Weather Changer'];
  // model = new AppointmentForm(18, 'Dr. IQ', 'Doctor', 'No');
  model = {
    id : 0,
    name : "",
    profession: "",
    available: "",
    date: "",
    time: "",
    phone: "",
  }

  submitted = false;

  ngOnInit(): void {}

  onSubmit(AppForm: any) {
    this.submitted = true;
    // this.appService.addAppointment()
    console.log(this.model, '--------');
    this.appService
      .addAppointment(this.model)
      .subscribe((data) => console.log('Inside post:----->', data));

    AppForm.reset();
  }
}

import { Component } from '@angular/core';
import { AppService } from '../app.service';
import { AppointmentForm } from '../appointment-form';

@Component({
  selector: 'app-booked-appt',
  templateUrl: './booked-appt.component.html',
  styleUrls: ['./booked-appt.component.css'],
})
export class BookedApptComponent {
  constructor(public appService: AppService) {}

  // DATA: AppointmentForm[] = [];
  DATA: any[]  = [];

  ngOnInit() {
    this.appService.getAppointments().subscribe((data: any[]) => {
      this.DATA = data;
      console.log('Inside post: ', typeof(data), data);
    });
  }
}

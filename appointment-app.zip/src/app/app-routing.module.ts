import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppointmentFormComponent } from './appointment-form/appointment-form.component';
import { BookedApptComponent } from './booked-appt/booked-appt.component';

const routes: Routes = [
  { path: 'appointments', component: BookedApptComponent },
  { path: 'form', component: AppointmentFormComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

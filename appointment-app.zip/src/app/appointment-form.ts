export class AppointmentForm {

    constructor(
      public id: number,
      public name: string,
      public profession: string,
      public available: string,
      public alterEgo?: string
    ) {  }
  
  }
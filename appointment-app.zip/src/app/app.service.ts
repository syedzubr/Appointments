import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

// const httpOptions = { 
//   headers: new HttpHeaders({
//     'Content-Type':'application/json'
//   })
// }

  @Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }

  rootURL = '/api';

  getAppointments() {
    return this.http.get<any[]>(this.rootURL + '/appointments');
    // this solved 1 day full error !!!!!!!!!!!!!!!!!!!!!
  }

  addAppointment(user: any) {
    return this.http.post(this.rootURL + '/appointment', user);
  }


}
